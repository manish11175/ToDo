import React from "react";
import Home from "./component/Home";





export default function App() {
  return (
    <>
      <Home />

    </>
  );
}
