import React from 'react'

export default function EditTask(props) {
    return (
        <div className="container-fluid my-5 show" id="editcol">
        <div className="row m-5" id="editrow">
         <div className="col-sm-12 col-md-6" id="card1">
             <h3 className="py-2">Edit task</h3>
             <div class="col-md-12 my-4" id="task">
               <form class="row g-3 mx-2">
                 <div class="col-sm-10">
                   <label for="task" class="visually-hidden">
                     Task
                   </label>
                   <input
                    value={props.title}
                     type="text"
                     class="form-control"
                     id="task"
                     name="newtask"
                     placeholder="task"
                    //  onChange={change}
                   />
                 </div>
                 <div class="col-sm-2">
                   <button
                     type="submit"
                     class="btn btn-outline-primary mb-3"
                    //  onClick={addTask}
                   >
                     edit
                   </button>
                 </div>
                 
               </form>
             </div>
             {/* {renderTask(task)} */}
           </div>
         </div>
   
        </div>
    )
}
